package com.user.entity;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Transactional
@Data
@NoArgsConstructor
@Table(name="Address")
public class Address {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(name="f_Add_id")
private int Add_id;
private String adress_type;
private String  street;
private String line1;
private String line2;
private String city;
private String state;
private String pincode;
}
